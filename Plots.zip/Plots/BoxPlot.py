#-------------------------------------------------------------------------------
# Name:        Bar Plot
# Purpose:	   Education
# Author:      Harish Agrawal
# Data: 	   District-wise, season-wise crop production statistics    
# https://data.gov.in/catalog/district-wise-season-wise-crop-production-statistics?filters%5Bfield_catalog_reference%5D=87631&format=json&offset=0&limit=6&sort%5Bcreated%5D=desc
#-------------------------------------------------------------------------------
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

 

agri_data = pd.read_csv('apy.csv')
agri_data_Coconut = agri_data[agri_data['Crop']=='Coconut ']

agri_data_karnataka_Coconut = agri_data_Coconut[agri_data_Coconut['State_Name']=='Karnataka']
agri_data_West_Bengal_Coconut = agri_data_Coconut[agri_data_Coconut['State_Name']=='West Bengal']
agri_data_Goa_Coconut = agri_data_Coconut[agri_data_Coconut['State_Name']=='Goa']
agri_data_Assam_Coconut = agri_data_Coconut[agri_data_Coconut['State_Name']=='Assam']
agri_data_Andaman_Coconut = agri_data_Coconut[agri_data_Coconut['State_Name']=='Andaman and Nicobar Islands']




# print(len(agri_data_karnataka_Coconut))
# 479
# print(agri_data_karnataka_Coconut.head())
#       State_Name District_Name  Crop_Year       Season      Crop    Area  Production
# 76895  Karnataka      BAGALKOT       1998  Whole Year   Coconut    571.0      2728.0
# 76931  Karnataka      BAGALKOT       1999  Whole Year   Coconut   1283.0      6130.0
# 76971  Karnataka      BAGALKOT       2000  Whole Year   Coconut   1312.0      6268.0
# 77011  Karnataka      BAGALKOT       2001  Whole Year   Coconut   1142.0      5456.0
# 77055  Karnataka      BAGALKOT       2002  Whole Year   Coconut    877.0      4190.0


unique_years_karnataka = agri_data_karnataka_Coconut['Crop_Year'].unique()
unique_years_West_Bengal = agri_data_West_Bengal_Coconut['Crop_Year'].unique()
unique_years_Goa = agri_data_Goa_Coconut['Crop_Year'].unique()
unique_years_Assam = agri_data_Assam_Coconut['Crop_Year'].unique()
unique_years_Andaman = agri_data_Andaman_Coconut['Crop_Year'].unique()
# print(unique_years)
# [1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008 2009 2010 2011 2012 2013 2014]


a = [agri_data_karnataka_Coconut[agri_data_karnataka_Coconut['Crop_Year']==i].Production.sum() for i in unique_years_karnataka]
b = [agri_data_West_Bengal_Coconut[agri_data_West_Bengal_Coconut['Crop_Year']==i].Production.sum() for i in unique_years_West_Bengal]
c = [agri_data_Goa_Coconut[agri_data_Goa_Coconut['Crop_Year']==i].Production.sum() for i in unique_years_Goa]
d = [agri_data_Assam_Coconut[agri_data_Assam_Coconut['Crop_Year']==i].Production.sum() for i in unique_years_Assam]
e = [agri_data_Andaman_Coconut[agri_data_Andaman_Coconut['Crop_Year']==i].Production.sum() for i in unique_years_Andaman]

# print(Coconut_production_perYear_ka)
# [1611530.0, 1614264.0, 1762403.0, 1503638.0, 1525287.0, 1529139.0, 15674043.29, 1606890.0, 
# 1635839.0, 2063855.0, 2867660.0, 3056353.0, 4213360.0, 4411600.0, 4342441.0, 3417792.0, 3931007.0]

data = [a,b,c,d,e]

aa=plt.boxplot(data)


h = [1,2,3,4,5]

# Plot axes labels and show the plot
# plt.legend([aa,bb,cc,dd,ee],['Karnataka','WestBengal','Goa','Assam','Andaman and Nicobar Islands'])
plt.title('Yearly Production VS States')
plt.xticks(h,['Karnataka','WestBengal','Goa','Assam','Andaman and Nicobar Islands'])
plt.ylabel('Production(Tonnes)')
plt.show()