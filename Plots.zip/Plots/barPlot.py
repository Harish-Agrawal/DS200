#-------------------------------------------------------------------------------
# Name:        Bar Plot
# Purpose:	   Education
# Author:      Harish Agrawal
# Data: 	   District-wise, season-wise crop production statistics    
# https://data.gov.in/catalog/district-wise-season-wise-crop-production-statistics?filters%5Bfield_catalog_reference%5D=87631&format=json&offset=0&limit=6&sort%5Bcreated%5D=desc
#-------------------------------------------------------------------------------
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

agri_data = pd.read_csv('apy.csv')
agri_data_2012 = agri_data[agri_data['Crop_Year']==2012]
agri_data_2012_Rice = agri_data_2012[agri_data_2012['Crop']=='Rice'] 

# # print(len(agri_data))
# # 246091
# # print(len(agri_data_2012))
# # 15104
# # print(len(agri_data_2012_Rice))
# # 844

# Taking out unique names of states that produced Rice in 2012
states = agri_data_2012_Rice['State_Name'].unique()

# Adding productions per state to get total production by each state
rice_production_area_state_2012 = [[agri_data_2012_Rice[agri_data_2012_Rice['State_Name']==i].Production.sum(),
									agri_data_2012_Rice[agri_data_2012_Rice['State_Name']==i].Area.sum(),
									i] for i in states]
# # print(len(rice_production_area_state_2012))
# # 24
# # print(rice_production_area_state_2012)
# # [[6862854.0, 'Andhra Pradesh'], [174662.0, 'Arunachal Pradesh'], [5120052.0, 'Assam'], 
# # [8322010.0, 'Bihar'], [7848401.0, 'Chhattisgarh'], [26704.0, 'Dadra and Nagar Haveli'], 
# # [122821.0, 'Goa'], [1497300.0, 'Gujarat'], [3941000.0, 'Haryana'], [3364379.0, 'Karnataka'], 
# # [508299.0, 'Kerala'], [3106146.0, 'Madhya Pradesh'], [3078040.0, 'Maharashtra'], 
# # [265653.0, 'Meghalaya'], [405180.0, 'Nagaland'], [9496000.0, 'Odisha'], [46519.0, 'Puducherry'], 
# # [11390000.0, 'Punjab'], [21340.0, 'Sikkim'], [4050334.0, 'Tamil Nadu'], [713222.0, 'Tripura'], 
# # [14415939.0, 'Uttar Pradesh'], [606891.0, 'Uttarakhand'], [14946735.0, 'West Bengal']]


# Sorting according to area
rice_production_area_state_2012.sort(key = lambda i:i[1],reverse=True)
# print(rice_production_area_state_2012)
# [[9496000.0, 12378000.0, 'Odisha'], [14415939.0, 5861282.0, 'Uttar Pradesh'], 
# [14946735.0, 5444318.0, 'West Bengal'], [7848401.0, 3982172.0, 'Chhattisgarh'], 
# [8322010.0, 3298887.0, 'Bihar'], [11390000.0, 2849000.0, 'Punjab'], [5120052.0, 2484728.0, 'Assam'], 
# [6862854.0, 2209237.0, 'Andhra Pradesh'], [3106146.0, 1791157.0, 'Madhya Pradesh'], 
# [3078040.0, 1559000.0, 'Maharashtra'], [4050334.0, 1493276.0, 'Tamil Nadu'], 
# [3364379.0, 1278915.0, 'Karnataka'], [3941000.0, 1206255.0, 'Haryana'], [1497300.0, 701100.0, 'Gujarat'], 
# 606891.0, 269237.0, 'Uttarakhand'], [713222.0, 254743.0, 'Tripura'], [508299.0, 197277.0, 'Kerala'], 
# [405180.0, 183330.0, 'Nagaland'], [174662.0, 126085.0, 'Arunachal Pradesh'], 
# [265653.0, 109751.0, 'Meghalaya'], [122821.0, 45830.0, 'Goa'], [46519.0, 16281.0, 'Puducherry'], 
# [26704.0, 13834.0, 'Dadra and Nagar Haveli'], [21340.0, 11920.0, 'Sikkim']]

# Filtering - Production below 3 million is added into others
states_prod_above3million = [i for i in rice_production_area_state_2012 if i[0]>=3000000]
prod_below3million = [i[0] for i in rice_production_area_state_2012 if i[0]<3000000]

# Summing production data of other states
production_others = sum(prod_below3million)

arr_prod = np.array(states_prod_above3million)

# Taking out states and production data from numpy multi-dimensional array
states_filtered = arr_prod[:,2]
production_filtered = [float(i) for i in arr_prod[:,0]]

# Appending others data
states_filtered = np.append(states_filtered,'Others')
production_filtered = np.append(production_filtered,production_others)

# Plotting the data using bar plot
plt.bar(states_filtered,production_filtered)

# Plot axes labels and show the plot
plt.title('Rice Production VS States  (Data of 2012)')
# plt.xlabel('')
plt.ylabel('Production(Tonnes)')
plt.xticks(rotation=45)
plt.show()
