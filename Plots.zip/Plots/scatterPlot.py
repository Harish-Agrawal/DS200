#-------------------------------------------------------------------------------
# Name:        Scatter Plot
# Purpose:	   Education
# Author:      Harish Agrawal
# Data: 	   District-wise, season-wise crop production statistics    
# https://data.gov.in/catalog/district-wise-season-wise-crop-production-statistics?filters%5Bfield_catalog_reference%5D=87631&format=json&offset=0&limit=6&sort%5Bcreated%5D=desc
#-------------------------------------------------------------------------------
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

agri_data = pd.read_csv('apy.csv')
agri_data_2012 = agri_data[agri_data['Crop_Year']==2012]
states = agri_data_2012['State_Name'].unique()

# print(len(agri_data))
# 246091

# print(len(agri_data_2012))
# 13410

# print(len(states))
# 24

# print(states)
# ['Andhra Pradesh' 'Arunachal Pradesh' 'Assam' 'Bihar' 'Chhattisgarh'
#  'Dadra and Nagar Haveli' 'Goa' 'Gujarat' 'Haryana' 'Karnataka' 'Kerala'
#  'Madhya Pradesh' 'Maharashtra' 'Meghalaya' 'Nagaland' 'Odisha'
#  'Puducherry' 'Punjab' 'Sikkim' 'Tamil Nadu' 'Tripura' 'Uttar Pradesh'
#  'Uttarakhand' 'West Bengal']

# print(agri_data_2012.head())
#          State_Name District_Name  Crop_Year       Season         Crop     Area  Production
# 798  Andhra Pradesh     ANANTAPUR       2012  Kharif          Arecanut    558.0       302.0
# 799  Andhra Pradesh     ANANTAPUR       2012  Kharif         Arhar/Tur  56586.0      8035.0
# 800  Andhra Pradesh     ANANTAPUR       2012  Kharif             Bajra   2176.0      1456.0
# 801  Andhra Pradesh     ANANTAPUR       2012  Kharif           Brinjal    451.0      8211.0
# 802  Andhra Pradesh     ANANTAPUR       2012  Kharif       Castor seed  24154.0      9179.0

# State-wise Summing area and production 
area = [agri_data_2012[agri_data_2012['State_Name']==i].Area.sum() for i in states]
production = [agri_data_2012[agri_data_2012['State_Name']==i].Production.sum() for i in states]

# Filtering out outliers
area_1 = np.array([(area[i],production[i]) for i in range(len(area)) if production[i]<1000000000],dtype=int)

area_filtered = area_1[:,0]
production_filtered = area_1[:,1]

# Setting up plotting
fig = plt.figure()

# Plotting the data
a=plt.scatter(area_filtered,production_filtered,s=50)
b=plt.scatter(area_filtered,area_filtered*5,c='r',s=10)


# Plot axes labels and show the plot
plt.legend([a,b],['True Data','y=5x'])
plt.title('Crop Production VS Crop Covered Area (Data of 2012)')
plt.xlabel('Area(Hectare)')
plt.ylabel('Production(Tonnes)')
plt.show()
